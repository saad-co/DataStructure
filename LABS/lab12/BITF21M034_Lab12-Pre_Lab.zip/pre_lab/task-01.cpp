#include<iostream>
using namespace std;
const int Max_Vertex=50;
class Graph
{
private:
     int **Adj_Matrix; 
     int Vertex;
     int Edge; 
public:
     Graph(){
        Vertex=0;
        Edge=0;
       
       Adj_Matrix=new int*[Max_Vertex];
       for(int i=0;i<Max_Vertex;i++){
         Adj_Matrix[i]=new int[Max_Vertex];
         for(int j=0;j<Max_Vertex;j++){
            Adj_Matrix[i][j]=0;
         }
             
       }
     }
     ~Graph(){
        for(int i=0;i<Max_Vertex;i++){
            delete []Adj_Matrix[i];
        }
        delete []Adj_Matrix;
     }
    bool IsEmpty(){
        return Vertex==0;
    }

  void Insert_Vertex(int u){
    if(u>=0 && u<Max_Vertex){
        Vertex++;
    }
    else{
       throw invalid_argument("Invalid Index");
    }
  }
void Insert_Edge(int u, int v){
    if(u>=0 && u<Max_Vertex && v>=0 && v<Max_Vertex ){
        Adj_Matrix[u][v]=1;
        Adj_Matrix[v][u]=1;
        Edge++;
    }
    else{
        throw invalid_argument("Invalid Index");
    }
}
void Delete_Vertex(int u){
    if(u>=0 && u<Max_Vertex){
    for(int i=0;i<Max_Vertex;i++){
        if(Adj_Matrix[u][i]==1){
            Adj_Matrix[u][i] =0;
            Adj_Matrix[i][u] =0;
            Edge--;
        }
    }
     Vertex--;
    }
    else{
        throw invalid_argument("Invalid Index");
    }
}
void Delete_Edge(int u, int v){
    if(u>=0 && u<Max_Vertex && v>=0 && v<Max_Vertex ){
        Adj_Matrix[u][v]=0;
        Adj_Matrix[v][u]=0;
        Edge--;
    }
    else{
        throw invalid_argument("Invalid Index");
    }
}

int getVertices(){
    return Vertex;
}
int getEdges(){
    return Edge;
}

void Print() {
    for (int i = 0; i < Vertex; ++i) {
        for (int j = 0; j < Vertex; ++j) {
            cout << Adj_Matrix[i][j] << " ";
        }
        cout << endl;
    }
}
};

int main() {
    Graph G1;

    G1.Insert_Vertex(0);
    G1.Insert_Vertex(1);
    G1.Insert_Vertex(2);
    cout<<"Number of Vertices : "<<G1.getVertices()<<endl;

    G1.Insert_Edge(0, 1);
    G1.Insert_Edge(1, 2);
    cout<<"Number of Edges : "<<G1.getEdges()<<endl;
    G1.Print();
    cout<<"After Deleting Edge  "<<endl;
    G1.Delete_Edge(0, 1);
     G1.Print();
    cout<<"After Deleting Vertex  "<<endl;
    G1.Delete_Vertex(2);

    G1.Print();
    return 0;
}